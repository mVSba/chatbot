document.addEventListener('DOMContentLoaded', function() {
    const messageForm = document.getElementById('message-form');
    const userInput = document.getElementById('user-input');
    const chatMessages = document.getElementById('chat-messages');
    const resetButton = document.getElementById('reset-chat');
    const quickReplies = document.getElementById('quick-replies');
    const quickReplyButtons = document.querySelectorAll('.quick-reply-btn');

    // Scroll to bottom of chat
    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Add a new message to the chat
    function addMessage(message, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';
        messageContent.textContent = message;
        
        messageDiv.appendChild(messageContent);
        chatMessages.appendChild(messageDiv);
        
        scrollToBottom();
    }
    
    // Handle quick reply button clicks
    quickReplyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const message = this.getAttribute('data-message');
            sendMessage(message);
        });
    });

    // Send message function (used by both quick replies and form input)
    function sendMessage(message) {
        if (!message) return;
        
        // Clear input field if this was from the form
        userInput.value = '';
        
        // Show thinking indicator
        const thinkingDiv = document.createElement('div');
        thinkingDiv.className = 'message bot-message thinking';
        thinkingDiv.innerHTML = '<div class="message-content">Thinking...</div>';
        chatMessages.appendChild(thinkingDiv);
        scrollToBottom();
        
        // Send message to server
        fetch('/send_message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `message=${encodeURIComponent(message)}`
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Remove thinking indicator
            chatMessages.removeChild(thinkingDiv);
            
            // Add the user's message and bot's response
            addMessage(data.user_message, 'user');
            addMessage(data.bot_response, 'bot');
        })
        .catch(error => {
            console.error('Error:', error);
            // Remove thinking indicator
            chatMessages.removeChild(thinkingDiv);
            
            // Show error message
            addMessage("I'm sorry, I couldn't process your message. Please try again.", 'bot');
        });
    }
    
    // Form submission handler
    messageForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const message = userInput.value.trim();
        sendMessage(message);
    });

    // Reset chat button
    resetButton.addEventListener('click', function() {
        if (confirm('Are you sure you want to start a new conversation?')) {
            fetch('/reset_chat', {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Clear chat messages
                    chatMessages.innerHTML = '';
                    
                    // Add welcome message
                    addMessage("Hi there! I'm here to help you through difficult moments. If you're experiencing a panic attack or anxiety, I can offer some coping techniques. How are you feeling right now?", 'bot');
                }
            });
        }
    });

    // Initial scroll to bottom
    scrollToBottom();

    // Focus input field
    userInput.focus();
});
